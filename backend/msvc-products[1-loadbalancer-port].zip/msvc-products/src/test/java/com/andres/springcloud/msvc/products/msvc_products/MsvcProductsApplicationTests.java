package com.andres.springcloud.msvc.products.msvc_products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
