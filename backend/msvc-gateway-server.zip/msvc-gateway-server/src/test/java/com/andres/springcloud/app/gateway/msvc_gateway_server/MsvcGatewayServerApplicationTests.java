package com.andres.springcloud.app.gateway.msvc_gateway_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
