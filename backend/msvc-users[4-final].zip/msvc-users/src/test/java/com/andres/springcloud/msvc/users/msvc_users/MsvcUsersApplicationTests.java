package com.andres.springcloud.msvc.users.msvc_users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
